# Prisma Creative Studio

Creative studio landing page with editorial copy and expressive visual direction.

## Local preview

Open this file directly in a browser after cloning the repository:

```text
examples/premium-website-showcase/demos/prisma-creative-studio/preview.html
```

Optional local server from the repository root:

```bash
cd examples/premium-website-showcase/demos/prisma-creative-studio
python3 -m http.server 4173
```

Then visit:

```text
http://localhost:4173/preview.html
```

## Why this demo exists

This demo is part of the public proof-of-output gallery for the Codex Premium Website Skills library. It demonstrates how the skill collection can move from a prompt, reference, spec, or visual direction into a polished local web artifact quickly.
